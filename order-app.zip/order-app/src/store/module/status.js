const state = {
  isLogin:false
};

const getters = {
  isLogin : state => state.isLogin
};

const mutations = {

};

const actions = {

};

export default {
  state,
  getters,
  mutations,
  actions
}
