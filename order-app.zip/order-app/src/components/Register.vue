<template>
  <div class="row mt-3">
    <div class="col-md-12 col-lg-12">
      <div class="card">
        <div class="card-body">
          <img class="mx-auto d-block" src="../assets/register.png" alt="">
          <form @submit.prevent="onSubmit" action="">
            <div class="form-group">
              <label for="email">邮箱</label>
              <input type="email" id="email" class="form-control" v-model="email">
            </div>
            <div class="form-group">
              <label for="pass">密码</label>
              <input type="password" id="pass" class="form-control" v-model="password">
            </div>
            <div class="form-group">
              <label for="">确认密码</label>
              <input type="password" id="" class="form-control" v-model="confirmPassword">
            </div>
            <button type="submit" class="btn btn-block btn-success">注册</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import axios from 'axios'
  export default {
    name: "",
    data(){
      return {
        email:'',
        password:'',
        confirmPassword:''
      }
    },
    methods:{
      onSubmit(){
        if (this.password === this.confirmPassword){
          const formData = {
            email: this.email,
            password: this.password
          };
          axios.post('/users.json',formData).then(res => {
            //console.log(res);
            this.$router.push({name:'loginLink'});

          }).catch(err => {
            console.log(err);
          })
        }else{
          alert('密码不一致！');
        }

      }
    }

  }
</script>

<style scoped>

</style>
