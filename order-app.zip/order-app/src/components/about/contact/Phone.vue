<template>
    <h1>0769-00000000</h1>
</template>

<script>
    export default {
        name: ""
    }
</script>

<style scoped>

</style>
