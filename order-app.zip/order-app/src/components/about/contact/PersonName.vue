<template>
    <h1>Normchin</h1>
</template>

<script>
    export default {
        name: ""
    }
</script>

<style scoped>

</style>
