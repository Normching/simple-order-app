<template>
  <div class="card text-dark bg-light mb-3">
    <div class="card-header">历史订单</div>
    <div class="card-body">
      <h4 class="card-title">历史订单</h4>
      <p class="card-text">753152973@qq.com</p>
    </div>
  </div>
</template>

<script>
    export default {
        name: ""
    }
</script>

<style scoped>

</style>
